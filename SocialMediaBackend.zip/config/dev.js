module.exports = {
    // MONGOURI : "mongodb://127.0.0.1:27017",
    MONGOURI: "mongodb+srv://Ankit_nagar:social07@cluster0.c4y9s.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
    JWT_SECRET : 'opbolte'
}